package com.example.expensemanager;

public interface OnItemsCLick {
    void onClick(ExpenseModel expenseModel);
}
